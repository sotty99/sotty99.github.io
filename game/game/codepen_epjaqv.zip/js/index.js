var name, className, mana, weaponName, DMG, spell1, spell2, spell3, spell4, manaPotion, healthPotion, dodge, health, magic, crit, special;

function functionOne() {
  name = prompt("What is your name?");
  var var1 = true;
  manaPotion = 3;
  healthPotion = 3;
  special = "None";
  while (var1 == true) {
    var clas = prompt("Choose a number relative to your class.\n 1. Marksman \n 2. Warrior \n 3. Mage \n 4. Rogue")
    if (isNaN(clas) == false) {
      if (clas == "1" || '2' || '3' || '4') {
        var1 = false;
      }
    }
  }
  var randOne = Math.random()
  switch(clas) {
    case 1:
      className = "Marksman";
      mana = 300;
      DMG = 55;
      health = 300;
      dodge = 0;
      if (randOne <= 0.25) {
        weaponName = "Doran's Bow";
        DMG = DMG + 10;
        health = health + 30;
      }
      else if (randOne <= 0.5) {
        weaponName = "Long Bow";
        DMG = DMG + 20;
      }
      else if (randOne <= 0.75) {
        weaponName = "Recurve Shield";
        health = health + 100;
        special = 'recurve';
      }
      else if (randOne <= 1) {
        weaponName = "Marksman's Boots";
        dodge = 10;
        crit = 20
      }
      break;
    case 2:
      className = "Warrior";
      mana = 180;
      DMG = 35;
      health = 500;
      if (randOne <= 0.25) {
        weaponName = "Doran's Blade";
        DMG = DMG + 7;
        health = health + 50;
      }
      else if (randOne <= 0.5) {
        weaponName = "Long Sword";
        DMG = DMG + 15;
      }
      else if (randOne <= 0.75) {
        weaponName = "Avarice Cutlass";
        crit = 15;
        health = heatlh + 40;
      }
      else if (randOne <= 1) {
        weaponName = "Delvish Blade";
        dodge = 10;
        special = 'fire';
      }
      break;
    case 3:
      className = "Mage";
      mana = 420;
      DMG = 5;
      health = 300;
      if (randOne <= 0.25) {
        weaponName = "Doran's Staff";
        magic = 20;
        mana = mana + 30;
      }
      else if (randOne <= 0.5) {
        weaponName = "Bloodmoon Wand";
        magic = 30;
      }
      else if (randOne <= 0.75) {
        weaponName = "Prototype Hexstaff";
        magic = 5;
        crit = 10;
        special = 'poison';
      }
      else if (randOne <= 1) {
        weaponName = "Sorcerer's Shoes";
        dodge = 20;
        health = health + 60;
      }
      break;
    case 4:
      className = "Rogue";
      mana = 240;
      DMG = 65;
      health = 200;
      dodge = 10;
      if (randOne <= 0.25) {
        weaponName = "Shining Dagger";
        crit = 25;
      }
      else if (randOne <= 0.5) {
        weaponName = "Sunfire's Shiv";
        health = health + 30;
      }
      else if (randOne <= 0.75) {
        weaponName = "Vampiric Knife";
        DMG = DMG + 10;
      }
      else if (randOne <= 1) {
        weaponName = "Frostfang Sabre";
        mana = mana + 30;
        special = 'ice';
      }
      break;
  }
  document.getElementById('starto').style.display = 'none';
  document.write('Name: ' + name + '<br>');
  document.write('Class: ' + className + '<br>');
  document.write('Health: ' + health + '<br>');
  document.write('Mana: ' + mana + '<br>');
  document.write('Attack Damage: ' + DMG + '<br>');
  document.write('Magic: ' + magic + '<br>');
  document.write('Weapon: ' + weaponName + '<br>');
  document.write('Dodge Chance: ' + dodge + '%<br>');
  document.write('Critical Attack Chance: ' + crit + '%<br>');
  document.write('Special Attack')
  document.write('Health Potion(s): ' + healthPotion + '<br>');
  document.write('Mana Potion(s): ' + manaPotion + '<br>');
  document.write('Special Effect: ' + special + '<br>');
}